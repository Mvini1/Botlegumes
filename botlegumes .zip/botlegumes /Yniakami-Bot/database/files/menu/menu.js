const menu = (pushname, sender, NomeBot, patt, emoji, numeroDono, nomeDono, prefixo) => { 
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭━─━─━─≪_⌾_≫─━─━─━╮
│╭━─━─≪_⌾_≫─━─━╮
│ ▏     ◥ 𝘐𝘯𝘧𝘰 𝘋𝘰 𝘉𝘰𝘵 ◤
│┣━━━━━━━━━━┓
│ ▏Nome: ${NomeBot}
│ ▏Prefixo: ${prefixo}
│ ▏Nome Do Dono: ${nomeDono}
│ ▏Numero Do Dono: ${numeroDono}
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏   ◥ 𝘐𝘯𝘧𝘰 𝘋𝘰 𝘜𝘴𝘶𝘢𝘳𝘪𝘰 ◤
│┣━━━━━━━━━━┓
│ ▏Nome: ${pushname}
│ ▏Numero: ${sender.split("@")[0]}
│ ▏Patente: ${patt}
│┗━━━━━━━━━━┛
 ▏
│╭━─━─≪_⌾_≫─━─━╮
│ ▏  ◥ 𝘉𝘳𝘪𝘯𝘤𝘢𝘥𝘦𝘪𝘳𝘢𝘴 ◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}Cassino
│ ▏${emoji} ${prefixo}Anagrama
│ ▏${emoji} ${prefixo}Cartafofa
│ ▏${emoji} ${prefixo}Jogodaforca
│ ▏${emoji} ${prefixo}resetforca
│ ▏${emoji} ${prefixo}gay
│ ▏${emoji} ${prefixo}feio
│ ▏${emoji} ${prefixo}matar
│ ▏${emoji} ${prefixo}bebado
│ ▏${emoji} ${prefixo}vesgo
│ ▏${emoji} ${prefixo}corno
│ ▏${emoji} ${prefixo}beijo
│ ▏${emoji} ${prefixo}gostoso
│ ▏${emoji} ${prefixo}gado
│ ▏${emoji} ${prefixo}gostosa
│ ▏${emoji} ${prefixo}dogolpe
│ ▏${emoji} ${prefixo}chutar
│ ▏${emoji} ${prefixo}tapa
│ ▏${emoji} ${prefixo}shipo
│ ▏${emoji} ${prefixo}casal
│ ▏${emoji} ${prefixo}nazista
│ ▏${emoji} ${prefixo}rankgay
│ ▏${emoji} ${prefixo}rankgado
│ ▏${emoji} ${prefixo}rankcorno
│ ▏${emoji} ${prefixo}rankgostosos
│ ▏${emoji} ${prefixo}rankgostosas
│ ▏${emoji} ${prefixo}rankotakus
│ ▏${emoji} ${prefixo}ranknazista
│ ▏${emoji} ${prefixo}rankpau
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏      ◥ Grupo ◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}Repetir
│ ▏${emoji} ${prefixo}Calculadora
│ ▏${emoji} ${prefixo}Nomegp
│ ▏${emoji} ${prefixo}Descgp
│ ▏${emoji} ${prefixo}Fotogp
│ ▏${emoji} ${prefixo}Totag
│ ▏${emoji} ${prefixo}Hidetag
│ ▏${emoji} ${prefixo}Linkgp
│ ▏${emoji} ${prefixo}Promover
│ ▏${emoji} ${prefixo}Rebaixar
│ ▏${emoji} ${prefixo}Ban
│ ▏${emoji} ${prefixo}Add
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏   ◥ 𝘍𝘪𝘨𝘶𝘳𝘪𝘯𝘩𝘢 ◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}F
│ ▏${emoji} ${prefixo}Fig
│ ▏${emoji} ${prefixo}Figura
│ ▏${emoji} ${prefixo}figurinha
│ ▏${emoji} ${prefixo}Stickergif
│ ▏${emoji} ${prefixo}figgif
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏    ◥ 𝘗𝘳𝘦𝘮𝘪𝘶𝘮n◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}Serpremium
│ ▏${emoji} ${prefixo}Addpremium
│ ▏${emoji} ${prefixo}Delpremium
│ ▏${emoji} ${prefixo}Premiumlist
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏     ◥ 𝘋𝘪𝘷𝘦𝘳𝘴𝘰𝘴 ◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}Enquete
│ ▏${emoji} ${prefixo}Ping
│ ▏${emoji} ${prefixo}Reagir
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
│ ▏      ◥ 𝘓𝘦𝘷𝘦𝘭 ◤
│┣━━━━━━━━━━┓
│ ▏${emoji} ${prefixo}Leveling
│ ▏${emoji} ${prefixo}Level
│ ▏${emoji} ${prefixo}Ganharlevel
│ ▏${emoji} ${prefixo}Ganharxp
│┗━━━━━━━━━━┛
│
│╭━─━─≪_⌾_≫─━─━╮
││❝❴${time2}❵❞
│╰━─━─≪_⌾_≫─━─━╯
╰━─━─━─≪_⌾_≫─━─━─━╯
`
}
exports.menu = menu
